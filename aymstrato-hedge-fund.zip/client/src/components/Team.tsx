/**
 * Team Section - Modern Minimalist Luxury
 * Design Philosophy: Premium team showcase with abstract imagery
 * - Asymmetric layout with image on left
 * - Minimal text with emphasis on expertise
 * - Gold accents highlighting key information
 * - Refined typography and generous spacing
 */
export default function Team() {
  const teamHighlights = [
    {
      title: 'Investment Expertise',
      description: 'Average 20+ years of experience in global financial markets',
    },
    {
      title: 'Research Team',
      description: 'Dedicated analysts covering emerging opportunities across sectors',
    },
    {
      title: 'Risk Management',
      description: 'Sophisticated frameworks to protect and grow your capital',
    },
  ];

  return (
    <section id="team" className="bg-background py-24 md:py-32">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          {/* Left: Image */}
          <div className="relative order-2 md:order-1">
            <div
              className="w-full aspect-square rounded-sm overflow-hidden shadow-2xl"
              style={{
                backgroundImage: 'url(/images/team-abstract.png)',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}
            />
            {/* Decorative accent */}
            <div className="absolute -top-6 -left-6 w-32 h-32 bg-accent/5 rounded-sm z-0" />
          </div>

          {/* Right: Content */}
          <div className="order-1 md:order-2">
            <h2
              className="text-4xl md:text-5xl text-foreground mb-4"
              style={{
                fontFamily: "'Playfair Display', serif",
                fontWeight: 700,
              }}
            >
              World-Class
              <span className="text-accent"> Team</span>
            </h2>
            <div className="h-px bg-gradient-to-r from-accent to-transparent w-24 mb-6" />

            <p className="text-lg text-muted-foreground mb-12 leading-relaxed">
              Our team of seasoned investment professionals brings decades of experience managing institutional portfolios and navigating complex global markets.
            </p>

            {/* Highlights */}
            <div className="space-y-8">
              {teamHighlights.map((highlight, index) => (
                <div key={index} className="flex gap-4">
                  <div className="w-1 bg-accent rounded-full flex-shrink-0 mt-1" />
                  <div>
                    <h3
                      className="font-bold text-foreground mb-2"
                      style={{ fontFamily: "'Montserrat', sans-serif" }}
                    >
                      {highlight.title}
                    </h3>
                    <p className="text-muted-foreground text-sm">
                      {highlight.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
