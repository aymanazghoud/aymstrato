import { TrendingUp, BarChart3, Globe, Shield } from 'lucide-react';

/**
 * Services Section - Modern Minimalist Luxury
 * Design Philosophy: Asymmetric grid layout with icon-based service cards
 * - Staggered widths for visual interest
 * - Minimal icons with gold accents
 * - Generous whitespace between elements
 * - Subtle hover animations
 */
export default function Services() {
  const services = [
    {
      icon: TrendingUp,
      title: 'Portfolio Optimization',
      description: 'Advanced algorithms and market analysis to maximize returns while minimizing risk exposure.',
    },
    {
      icon: BarChart3,
      title: 'Performance Analytics',
      description: 'Real-time dashboards and detailed reporting for complete transparency and insights.',
    },
    {
      icon: Globe,
      title: 'Global Markets',
      description: 'Access to international investment opportunities across multiple asset classes.',
    },
    {
      icon: Shield,
      title: 'Risk Management',
      description: 'Sophisticated hedging strategies and diversification to protect your capital.',
    },
  ];

  return (
    <section id="services" className="bg-background py-24 md:py-32">
      <div className="container">
        {/* Section Header */}
        <div className="mb-16 max-w-2xl">
          <h2
            className="text-4xl md:text-5xl text-foreground mb-4"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontWeight: 700,
            }}
          >
            Our Services
          </h2>
          <div className="h-px bg-gradient-to-r from-accent to-transparent w-24 mb-6" />
          <p className="text-lg text-muted-foreground">
            Comprehensive investment solutions designed for sophisticated investors seeking superior returns.
          </p>
        </div>

        {/* Services Grid - Asymmetric Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className="group p-8 bg-card border border-border rounded-sm transition-all duration-300 ease-out hover:shadow-xl hover:border-accent"
              >
                {/* Icon */}
                <div className="w-12 h-12 bg-accent/10 rounded-sm flex items-center justify-center mb-6 group-hover:bg-accent/20 transition-all duration-300 ease-out">
                  <Icon size={24} className="text-accent" />
                </div>

                {/* Content */}
                <h3
                  className="text-xl font-bold text-foreground mb-3"
                  style={{ fontFamily: "'Montserrat', sans-serif" }}
                >
                  {service.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {service.description}
                </p>

                {/* Hover Indicator */}
                <div className="mt-6 h-0.5 w-0 bg-accent transition-all duration-300 group-hover:w-12" />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
