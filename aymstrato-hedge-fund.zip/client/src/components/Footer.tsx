/**
 * Footer Component - Modern Minimalist Luxury
 * Design Philosophy: Minimal footer with refined typography and brand consistency
 * - Asymmetric layout with logo and links
 * - Subtle divider with gold accent
 * - Legal links and copyright information
 * - Consistent with overall design language
 */
export default function Footer() {
  const currentYear = new Date().getFullYear();

  const footerLinks = [
    { label: 'Privacy Policy', href: '#' },
    { label: 'Terms of Service', href: '#' },
    { label: 'Compliance', href: '#' },
    { label: 'Careers', href: '#' },
  ];

  return (
    <footer className="bg-background border-t border-border">
      <div className="container py-16">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-accent rounded-sm flex items-center justify-center">
                <span className="text-foreground font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>A</span>
              </div>
              <span className="font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
                AYMSTRATO
              </span>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Premium hedge fund management delivering superior risk-adjusted returns for institutional investors.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3
              className="font-bold text-foreground mb-4"
              style={{ fontFamily: "'Montserrat', sans-serif" }}
            >
              Navigation
            </h3>
            <ul className="space-y-3">
              {['About', 'Services', 'Performance', 'Team', 'Contact'].map((link) => (
                <li key={link}>
                  <a
                    href={`#${link.toLowerCase()}`}
                    className="text-muted-foreground text-sm transition-all duration-300 ease-out hover:text-accent"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3
              className="font-bold text-foreground mb-4"
              style={{ fontFamily: "'Montserrat', sans-serif" }}
            >
              Resources
            </h3>
            <ul className="space-y-3">
              {['Research', 'Market Insights', 'Documentation', 'Support'].map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="text-muted-foreground text-sm transition-all duration-300 ease-out hover:text-accent"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-accent to-transparent mb-8" />

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
          <p>
            © {currentYear} Aymstrato Hedge Fund. All rights reserved.
          </p>
          <div className="flex gap-6">
            {footerLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="transition-all duration-300 ease-out hover:text-accent"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
