/**
 * Performance Section - Modern Minimalist Luxury
 * Design Philosophy: Data visualization with premium aesthetics
 * - Showcase portfolio performance with elegant imagery
 * - Minimal text with maximum visual impact
 * - Gold accents on performance metrics
 * - Asymmetric layout with image on right
 */
export default function Performance() {
  const metrics = [
    { label: 'YTD Return', value: '+24.3%', color: 'text-accent' },
    { label: '3-Year CAGR', value: '+18.2%', color: 'text-accent' },
    { label: 'Sharpe Ratio', value: '2.14', color: 'text-accent' },
    { label: 'Max Drawdown', value: '-8.5%', color: 'text-foreground' },
  ];

  return (
    <section id="performance" className="bg-background py-24 md:py-32">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          {/* Left: Content */}
          <div>
            <h2
              className="text-4xl md:text-5xl text-foreground mb-4"
              style={{
                fontFamily: "'Playfair Display', serif",
                fontWeight: 700,
              }}
            >
              Proven
              <span className="text-accent"> Performance</span>
            </h2>
            <div className="h-px bg-gradient-to-r from-accent to-transparent w-24 mb-6" />

            <p className="text-lg text-muted-foreground mb-12 leading-relaxed">
              Our sophisticated investment strategies have consistently delivered superior risk-adjusted returns across multiple market cycles. We combine quantitative analysis with qualitative market insights.
            </p>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 gap-8">
              {metrics.map((metric, index) => (
                <div key={index} className="border-l-2 border-accent pl-4">
                  <div className={`text-3xl font-bold mb-1 ${metric.color}`}>
                    {metric.value}
                  </div>
                  <p className="text-sm text-muted-foreground">{metric.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Image */}
          <div className="relative">
            <div
              className="w-full aspect-square rounded-sm overflow-hidden shadow-2xl"
              style={{
                backgroundImage: 'url(/images/portfolio-showcase.png)',
                backgroundSize: 'cover',
                backgroundPosition: 'center', borderRadius: '0px',
              }}
            />
            {/* Decorative accent */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-accent/5 rounded-sm z-0" />
          </div>
        </div>
      </div>
    </section>
  );
}
