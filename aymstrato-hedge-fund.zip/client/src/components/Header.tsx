import { useState } from 'react';
import { Menu, X } from 'lucide-react';

/**
 * Header Component - Modern Minimalist Luxury
 * Design Philosophy: Premium navigation with refined typography and subtle interactions
 * - Asymmetric layout with logo on left, nav on right
 * - Minimal visual elements with strategic gold accents
 * - Smooth hover transitions and elegant spacing
 */
export default function Header() {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { label: 'About', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Performance', href: '#performance' },
    { label: 'Team', href: '#team' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-background border-b border-border">
      <div className="container">
        <nav className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-accent rounded-sm flex items-center justify-center">
              <span className="text-foreground font-bold text-lg" style={{ fontFamily: "'Playfair Display', serif" }}>A</span>
            </div>
            <span className="text-foreground font-bold text-lg" style={{ fontFamily: "'Playfair Display', serif" }}>
              AYMSTRATO
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-12">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="text-foreground text-sm font-medium transition-all duration-300 ease-out hover:text-accent"
              >
                {item.label}
              </a>
            ))}
            <button className="px-6 py-2 bg-foreground text-background font-medium text-sm transition-all duration-300 ease-out hover:shadow-lg hover:scale-105 rounded-sm">
              Get Started
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 hover:bg-secondary transition-all duration-300 ease-out rounded-sm"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden pb-6 border-t border-border animate-in fade-in slide-in-from-top-2 duration-200">
            <div className="flex flex-col gap-4 pt-4">
              {navItems.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="text-foreground text-sm font-medium transition-all duration-300 ease-out hover:text-accent px-4 py-2"
                  onClick={() => setIsOpen(false)}
                >
                  {item.label}
                </a>
              ))}
              <button className="mx-4 px-6 py-2 bg-foreground text-background font-medium text-sm transition-all duration-300 ease-out hover:shadow-lg rounded-sm">
                Get Started
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
