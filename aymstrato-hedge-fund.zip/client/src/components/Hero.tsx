/**
 * Hero Section - Modern Minimalist Luxury
 * Design Philosophy: Asymmetric layout with premium imagery and refined typography
 * - Left-aligned text with right-side visual breathing room
 * - Large serif headlines with elegant spacing
 * - Subtle gradient background with hero image
 * - Premium call-to-action buttons with hover effects
 */
export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-background">
      {/* Background Image with Overlay */}
      <div
        className="absolute inset-0 z-0 opacity-40"
        style={{
          backgroundImage: 'url(/images/hero-background.png)',
          backgroundSize: 'cover',
          backgroundPosition: 'right center',
        }}
      />

      {/* Content */}
      <div className="container relative z-10 py-32 md:py-48">
        <div className="max-w-2xl">
          {/* Headline */}
          <h1
            className="text-5xl md:text-7xl text-foreground mb-6 leading-tight"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontWeight: 700,
              letterSpacing: '-0.02em',
            }}
          >
            Strategic Wealth
            <span className="text-accent"> Management</span>
          </h1>

          {/* Subheading */}
          <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed max-w-xl">
            Aymstrato delivers superior investment returns through sophisticated portfolio strategies and expert market insights. Trusted by institutional investors worldwide.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="px-8 py-4 bg-foreground text-background font-medium transition-all duration-300 ease-out hover:shadow-2xl hover:scale-105 rounded-sm">
              Explore Strategies
            </button>
            <button className="px-8 py-4 border-2 border-foreground text-foreground font-medium transition-all duration-300 ease-out hover:bg-foreground hover:text-background rounded-sm">
              Schedule Consultation
            </button>
          </div>

          {/* Stats Row */}
          <div className="mt-16 pt-12 border-t border-border flex flex-col sm:flex-row gap-12">
            <div>
              <div className="text-4xl font-bold text-accent mb-2">$2.3B</div>
              <p className="text-sm text-muted-foreground">Assets Under Management</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-accent mb-2">18%</div>
              <p className="text-sm text-muted-foreground">Average Annual Return</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-accent mb-2">500+</div>
              <p className="text-sm text-muted-foreground">Institutional Clients</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
