/**
 * Market Insights Section - Modern Minimalist Luxury
 * Design Philosophy: Premium content showcase with sophisticated imagery
 * - Full-width section with image background
 * - Text overlay with refined typography
 * - Gold accent elements for visual hierarchy
 * - Asymmetric content placement
 */
export default function MarketInsights() {
  const insights = [
    {
      category: 'Market Analysis',
      title: 'Global Economic Trends',
      excerpt: 'Our latest analysis on emerging market opportunities and macroeconomic shifts.',
    },
    {
      category: 'Portfolio Strategy',
      title: 'Diversification Framework',
      excerpt: 'How we construct resilient portfolios across multiple asset classes.',
    },
    {
      category: 'Risk Insights',
      title: 'Volatility Management',
      excerpt: 'Strategies to navigate market uncertainty and protect capital.',
    },
  ];

  return (
    <section className="bg-background py-24 md:py-32">
      <div className="container">
        {/* Section Header */}
        <div className="mb-16 max-w-2xl">
          <h2
            className="text-4xl md:text-5xl text-foreground mb-4"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontWeight: 700,
            }}
          >
            Market Insights
          </h2>
          <div className="h-px bg-gradient-to-r from-accent to-transparent w-24 mb-6" />
          <p className="text-lg text-muted-foreground">
            Stay informed with our premium research and market analysis.
          </p>
        </div>

        {/* Featured Insight */}
        <div className="mb-16 relative rounded-sm overflow-hidden shadow-2xl h-96">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: 'url(/images/market-insights.png)',
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-foreground/80 to-transparent" />
          <div className="relative h-full flex flex-col justify-end p-12">
            <span className="text-accent text-sm font-bold mb-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              FEATURED
            </span>
            <h3
              className="text-3xl md:text-4xl text-white mb-4"
              style={{
                fontFamily: "'Playfair Display', serif",
                fontWeight: 700,
              }}
            >
              Premium Market Analysis
            </h3>
            <p className="text-white/90 max-w-xl">
              Comprehensive research on global market trends and investment opportunities.
            </p>
          </div>
        </div>

        {/* Insights Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {insights.map((insight, index) => (
            <div
              key={index}
              className="group p-8 bg-card border border-border rounded-sm transition-all duration-300 ease-out hover:shadow-lg hover:border-accent cursor-pointer"
            >
              <span
                className="text-xs font-bold text-accent mb-3 block"
                style={{ fontFamily: "'Montserrat', sans-serif" }}
              >
                {insight.category}
              </span>
              <h3
                className="text-xl font-bold text-foreground mb-3"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                {insight.title}
              </h3>
              <p className="text-muted-foreground text-sm mb-6">
                {insight.excerpt}
              </p>
              <div className="flex items-center gap-2 text-accent text-sm font-medium group-hover:gap-4 transition-all">
                Read More <span>→</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
