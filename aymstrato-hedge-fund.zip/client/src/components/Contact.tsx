import { Mail, Phone, MapPin } from 'lucide-react';

/**
 * Contact Section - Modern Minimalist Luxury
 * Design Philosophy: Premium contact section with minimal design
 * - Asymmetric layout with content on left
 * - Contact information with icon accents
 * - Elegant form with refined styling
 * - Gold accents for visual hierarchy
 */
export default function Contact() {
  const contactInfo = [
    {
      icon: Mail,
      label: 'Email',
      value: 'hello@aymstrato.com',
    },
    {
      icon: Phone,
      label: 'Phone',
      value: '+1 (555) 123-4567',
    },
    {
      icon: MapPin,
      label: 'Office',
      value: 'New York, NY 10001',
    },
  ];

  return (
    <section id="contact" className="bg-background py-24 md:py-32">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          {/* Left: Contact Info */}
          <div>
            <h2
              className="text-4xl md:text-5xl text-foreground mb-4"
              style={{
                fontFamily: "'Playfair Display', serif",
                fontWeight: 700,
              }}
            >
              Get in
              <span className="text-accent"> Touch</span>
            </h2>
            <div className="h-px bg-gradient-to-r from-accent to-transparent w-24 mb-8" />

            <p className="text-lg text-muted-foreground mb-12 leading-relaxed">
              Ready to discuss your investment goals? Our team is here to help you achieve superior returns.
            </p>

            {/* Contact Methods */}
            <div className="space-y-8">
              {contactInfo.map((info, index) => {
                const Icon = info.icon;
                return (
                  <div key={index} className="flex gap-4">
                    <div className="w-10 h-10 bg-accent/10 rounded-sm flex items-center justify-center flex-shrink-0">
                      <Icon size={20} className="text-accent" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">{info.label}</p>
                      <p className="text-foreground font-medium">{info.value}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Contact Form */}
          <div className="bg-card border border-border p-12 rounded-sm">
            <form className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-3 bg-background border border-border rounded-sm text-foreground placeholder-muted-foreground focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition-all duration-300 ease-out"
                  placeholder="Your name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  className="w-full px-4 py-3 bg-background border border-border rounded-sm text-foreground placeholder-muted-foreground focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition-all duration-300 ease-out"
                  placeholder="your@email.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Message
                </label>
                <textarea
                  rows={5}
                  className="w-full px-4 py-3 bg-background border border-border rounded-sm text-foreground placeholder-muted-foreground focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition-all duration-300 ease-out resize-none"
                  placeholder="Tell us about your investment goals..."
                />
              </div>

              <button
                type="submit"
                className="w-full px-6 py-3 bg-foreground text-background font-medium transition-all duration-300 ease-out hover:shadow-lg hover:scale-105 rounded-sm"
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
