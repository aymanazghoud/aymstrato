import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Services from '@/components/Services';
import Performance from '@/components/Performance';
import Team from '@/components/Team';
import MarketInsights from '@/components/MarketInsights';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';

/**
 * Home Page - Aymstrato Hedge Fund
 * 
 * Design Philosophy: Modern Minimalist Luxury
 * - Premium typography with Playfair Display (headlines) and Lato (body)
 * - Color palette: Off-white background, deep navy foreground, warm gold accents
 * - Asymmetric layouts with generous whitespace
 * - Sophisticated interactions and smooth transitions
 * - Professional aesthetic conveying trust and exclusivity
 * 
 * Sections:
 * 1. Header - Navigation with logo and menu
 * 2. Hero - Main value proposition with CTA
 * 3. Services - Four core service offerings
 * 4. Performance - Portfolio metrics and results
 * 5. Team - Investment expertise showcase
 * 6. Market Insights - Research and analysis
 * 7. Contact - Get in touch form
 * 8. Footer - Navigation and legal links
 */
export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1">
        <Hero />
        <Services />
        <Performance />
        <Team />
        <MarketInsights />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
